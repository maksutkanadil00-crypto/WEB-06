# Event Registration API (Lab 6 – Spring Boot)

A small in-memory Spring Boot backend for the Event Registration scenario.
It exposes JSON GET endpoints, uses a service class and constructor-based dependency injection.
No database, no frontend, no full CRUD (these come in later laboratories).

## Requirements

- **JDK 17 or later** (developed against JDK 17 language level; works on 21)
- Gradle is **not** required to be installed – use the included Gradle wrapper.
- Spring Boot 3.5.7 (Gradle – Groovy), Spring Web only.

## How to run

```bash
# Linux / macOS
./gradlew bootRun

# Windows
gradlew.bat bootRun
```

The console should show `Tomcat started on port 8080` and `Started EventRegistrationApplication`.
Alternatively, run `EventRegistrationApplication` from IntelliJ IDEA.

Run the tests with `./gradlew test`.

## Endpoints

| Endpoint | Description |
|---|---|
| `GET http://localhost:8080/api/hello` | Welcome message from `EventService` |
| `GET http://localhost:8080/api/events` | JSON array with the three events |
| `GET http://localhost:8080/api/info` | Application name, course and semester from `application.properties` |
| `GET http://localhost:8080/api/events/{id}` | **Bonus:** one event, or a JSON 404 error if the id does not exist |

## Project structure

```
src/main/java/kz/iitu/registration/
  EventRegistrationApplication.java   entry point (@SpringBootApplication)
  controller/RegistrationController.java
  service/EventService.java
  model/EventInfo.java
src/main/resources/application.properties
```

## Controller, service and model

- **Model – `EventInfo`**: a Java record with `id`, `title` and `location`. Jackson turns it into JSON.
- **Service – `EventService`** (`@Service`): holds the business data – the welcome message and an in-memory
  `List<EventInfo>` (Web Design Workshop, JavaScript Quiz, IT Career Talk). It also finds an event by id.
- **Controller – `RegistrationController`** (`@RestController`, base path `/api`): handles HTTP requests and returns
  objects that Spring serializes to JSON. It reads `app.course` and `app.semester` with `@Value`.

## Dependency injection

`RegistrationController` declares `EventService` as a constructor parameter. Spring creates the `EventService` bean
(because of `@Service`) and passes it in when it creates the controller. The controller never calls
`new EventService()`, so the two classes are loosely coupled and the service is easy to replace or mock in tests.
