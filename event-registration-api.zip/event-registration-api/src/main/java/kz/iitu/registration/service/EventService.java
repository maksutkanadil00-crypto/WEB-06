package kz.iitu.registration.service;

import kz.iitu.registration.model.EventInfo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Business logic layer. Spring creates one instance (a bean) of this class
 * because of @Service and injects it wherever it is requested.
 */
@Service
public class EventService {

    private final List<EventInfo> events = List.of(
            new EventInfo(1, "Web Design Workshop", "Room 201"),
            new EventInfo(2, "JavaScript Quiz", "Computer Lab 3"),
            new EventInfo(3, "IT Career Talk", "Main Hall")
    );

    public String getWelcomeMessage() {
        return "Welcome to the Event Registration API";
    }

    public List<EventInfo> getAllEvents() {
        return events;
    }

    public Optional<EventInfo> findEventById(int id) {
        return events.stream()
                .filter(event -> event.id() == id)
                .findFirst();
    }
}
