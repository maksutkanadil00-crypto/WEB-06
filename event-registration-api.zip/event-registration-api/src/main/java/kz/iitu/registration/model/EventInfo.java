package kz.iitu.registration.model;

/**
 * Simple data model for an event. A record gives us the constructor,
 * getters (id(), title(), location()), equals/hashCode and toString for free.
 * Jackson serializes it to JSON: {"id":1,"title":"...","location":"..."}.
 */
public record EventInfo(int id, String title, String location) {
}
